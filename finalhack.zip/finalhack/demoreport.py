from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.pagesizes import landscape
from reportlab.lib.pagesizes import portrait
from reportlab.platypus import Image
import csv

filename = 'bitcoin_report.pdf'

c = canvas.Canvas(filename,pagesize=landscape(letter))
c.setFont('Helvetica',28,leading=None)
c.drawCentredString(415,500,"Bitcoin Report Generation")
c.setFont('Helvetica',24,leading=None)
c.drawCentredString(415,450,"Power Up Auto Report")
seal = 'repo.png'
c.drawImage(seal,350,50,width=None,height=None)
c.showPage()
c.save()
